from django import forms

class NewStudentForm(forms.Form):
    studentName = forms.CharField(max_length = 200)
    departmentName = forms.CharField(max_length = 200)


class NewMarkForm(forms.Form):
    subjectName = forms.CharField(max_length = 200)
    marks = forms.CharField(max_length = 200)