from django.urls import path
from . import views

urlpatterns = [
    path('', views.ShowStudentList, name="StudentList"),
    path('create/', views.CreateNewStudent, name="CreateNew"),
    path('update/<int:pk>', views.UpdateStudentDetails, name="Update"),
    path('delete/<int:pk>', views.DeleteStudent, name="Delete"),
    path('student/add/<int:pk>', views.AddMark, name="AddMark"),
    path('mark/<int:pk>', views.StudentMarkDetails, name="StudentMarkDetails"),
    path('updateMark/<int:pk>', views.UpdateStudentMarkDetails, name="UpdateMark"),
    path('deleteMark/<int:pk>', views.DeleteStudentMarkDetails, name="DeleteMark"),
]